const CANVAS_ENROLL_URL = "https://nhrhs.instructure.com/enroll/E36R7W";

const competitions: { name: string; internal?: boolean }[] = [
  { name: "The Presidential AI Challenge" },
  { name: "USAAIO" },
  { name: "Congressional App Challenge" },
  { name: "Internal club competitions", internal: true },
];

export default function Home() {
  return (
    <main className="club">
      <div className="club-ring club-ring--tl" aria-hidden="true" />
      <div className="club-ring club-ring--br" aria-hidden="true" />
      <div className="club-inner">
        <header className="club-hero">
          <div className="club-school">NHRHS</div>
          <h1>AI CLUB</h1>
          <p>
            All students are welcome!
            <br />
            Biweekly on Mondays in Room 133
          </p>
        </header>

        <section className="club-about">
          <div className="club-about-copy">
            <div className="club-card">
              <span className="club-kicker">Meetings</span>
              <span className="club-card-title">Every other Monday</span>
              <span className="club-card-detail">Room 133, Engineering Wing</span>
            </div>
            <div className="club-welcome">
              <h2>Everyone belongs here</h2>
              <p>
                The club supports all types of people. Beginner meetings require no
                prerequisites, and more advanced meetings go deeper for members with
                experience.
              </p>
            </div>
          </div>
          <img
            className="club-mark"
            src="/ai-head.svg"
            alt="NH logo inside a head of circuitry"
          />
        </section>

        <section className="club-competitions">
          <h2>Competitions</h2>
          <p>
            We participate in external competitions and run our own internal ones.
          </p>
          <ul>
            {competitions.map((item) => (
              <li key={item.name} className={item.internal ? "is-internal" : undefined}>
                {item.name}
              </li>
            ))}
          </ul>
        </section>

        <section className="club-join">
          <h2>Join us on Canvas!</h2>
          <a href={CANVAS_ENROLL_URL}>Enroll in the Canvas course</a>
        </section>
      </div>
    </main>
  );
}
