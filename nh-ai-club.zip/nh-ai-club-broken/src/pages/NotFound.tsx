import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <main className="club club-notfound">
      <div>
        <h1>404</h1>
        <p>Page not found</p>
        <Link to="/">Back to AI Club</Link>
      </div>
    </main>
  );
}
